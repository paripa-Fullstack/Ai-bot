# 🚀 БЫСТРЫЙ СТАРТ

## Установка за 5 минут

### 1️⃣ Установите Python 3.8+

```bash
# Проверка версии
python3 --version

# Если не установлен (Ubuntu/Debian):
sudo apt update
sudo apt install python3 python3-pip -y
```

### 2️⃣ Установите зависимости

```bash
pip3 install -r requirements.txt
```

### 3️⃣ Запустите бота

**Способ 1: Простой запуск**
```bash
python3 ai_telegram_bot.py
```

**Способ 2: Менеджер бота (рекомендуется)**
```bash
./bot_manager.sh
# Выберите: 1 - Запустить бота
```

**Способ 3: Запуск в фоне**
```bash
nohup python3 ai_telegram_bot.py > bot.log 2>&1 &
```

### 4️⃣ Готово! 🎉

Откройте Telegram → Найдите вашего бота → /start

---

## 📁 Структура проекта

```
📦 ai-telegram-bot/
├── 🤖 ai_telegram_bot.py      # Основной файл бота
├── 🛠️ admin_panel.py           # Админ-панель
├── 📢 broadcast.py             # Массовая рассылка
├── ⚙️ bot_manager.sh           # Менеджер управления
├── 📋 requirements.txt         # Зависимости
├── 📖 README.md               # Основная документация
├── 📘 QUICKSTART.md           # Быстрый старт (этот файл)
├── 🎯 MARKETING.md            # Маркетинговые материалы
├── ❓ FAQ.md                  # Частые вопросы
└── 💾 bot_users.db            # База данных (создается автоматически)
```

---

## 🎯 Основные команды

### Управление ботом

```bash
# Запуск
./bot_manager.sh start

# Остановка
./bot_manager.sh stop

# Перезапуск
./bot_manager.sh restart

# Статус
./bot_manager.sh status

# Логи
./bot_manager.sh logs

# Бэкап
./bot_manager.sh backup
```

### Администрирование

```bash
# Открыть админ-панель
python3 admin_panel.py

# Массовая рассылка
python3 broadcast.py
```

---

## ⚙️ Первоначальная настройка

### Настройте описание в BotFather

1. Откройте @BotFather в Telegram
2. Отправьте `/setdescription`
3. Выберите вашего бота
4. Скопируйте описание из `MARKETING.md`

### Настройте команды в BotFather

1. Отправьте `/setcommands` в @BotFather
2. Выберите вашего бота
3. Отправьте:

```
start - 🚀 Начать работу с ботом
help - ❓ Помощь и информация
status - 📊 Мой статус и использование
subscribe - 💎 Оформить подписку
history - 📜 История моих запросов
```

### Настройте изображение бота

1. Отправьте `/setuserpic` в @BotFather
2. Выберите вашего бота
3. Загрузите изображение (512x512 px)

---

## 💳 Настройка платежей

### Важно! Замените адреса криптокошельков

В файле `ai_telegram_bot.py` найдите:

```python
CRYPTO_ADDRESSES = {
    "TRC20": "ВАШ_TRC20_АДРЕС",
    "BTC": "ВАШ_BTC_АДРЕС"
}
```

### Настройте уведомления о платежах

В файле `ai_telegram_bot.py` найдите функцию `receipt_handler` и раскомментируйте:

```python
# Замените YOUR_ADMIN_ID на ваш Telegram ID
await context.bot.send_photo(
    chat_id=123456789,  # ВАШ TELEGRAM ID
    photo=file_id,
    caption=f"💳 Новый платеж!..."
)
```

**Как узнать свой Telegram ID:**
- Откройте @userinfobot
- Отправьте любое сообщение
- Скопируйте ваш ID

---

## 📊 Активация подписки пользователю

### Способ 1: Через админ-панель

```bash
python3 admin_panel.py
# Выберите: 4 - Активировать подписку
# Введите User ID и выберите тариф
```

### Способ 2: Через SQL

```bash
sqlite3 bot_users.db

# Недельная подписка
UPDATE users 
SET is_subscribed = 1, 
    subscription_end = datetime('now', '+7 days') 
WHERE user_id = USER_ID;

# Месячная подписка
UPDATE users 
SET is_subscribed = 1, 
    subscription_end = datetime('now', '+30 days') 
WHERE user_id = USER_ID;

# Годовая подписка
UPDATE users 
SET is_subscribed = 1, 
    subscription_end = datetime('now', '+365 days') 
WHERE user_id = USER_ID;
```

---

## 🔍 Мониторинг и логи

### Просмотр логов в реальном времени

```bash
tail -f bot.log
```

### Проверка статуса бота

```bash
./bot_manager.sh status
```

### Просмотр статистики

```bash
python3 admin_panel.py
# Выберите: 1 - Статистика
```

---

## 🔄 Автозапуск при перезагрузке сервера

### Ubuntu/Debian (systemd)

```bash
# Установка сервиса
./bot_manager.sh
# Выберите: 10 - Установить systemd сервис

# Управление
sudo systemctl start ai_telegram_bot
sudo systemctl stop ai_telegram_bot
sudo systemctl restart ai_telegram_bot
sudo systemctl status ai_telegram_bot
```

### Через cron

```bash
# Редактировать crontab
crontab -e

# Добавить строку (проверка каждые 5 минут, запуск если не работает)
*/5 * * * * cd /path/to/bot && ./bot_manager.sh start
```

---

## 💾 Регулярные бэкапы

### Ручной бэкап

```bash
./bot_manager.sh backup
```

### Автоматический бэкап (cron)

```bash
# Редактировать crontab
crontab -e

# Добавить строку (бэкап каждый день в 3:00)
0 3 * * * cd /path/to/bot && ./bot_manager.sh backup
```

---

## 🚨 Решение частых проблем

### Бот не запускается

```bash
# Проверьте зависимости
pip3 install -r requirements.txt

# Проверьте токен
# В файле ai_telegram_bot.py должен быть правильный BOT_TOKEN

# Проверьте логи
tail -f bot.log
```

### База данных заблокирована

```bash
# Остановите бота
./bot_manager.sh stop

# Подождите 2 секунды
sleep 2

# Запустите снова
./bot_manager.sh start
```

### API ошибка

```bash
# Проверьте API ключ DeepInfra
# В файле ai_telegram_bot.py: DEEPINFRA_API_KEY

# Проверьте лимиты на https://deepinfra.com/
```

---

## 📈 Маркетинг и продвижение

### Готовые материалы

Все маркетинговые материалы находятся в файле `MARKETING.md`:
- Описания для BotFather
- Рекламные тексты
- Идеи для продвижения
- Шаблоны постов

### Рассылка пользователям

```bash
python3 broadcast.py
# Выберите аудиторию и отправьте сообщение
```

---

## 📞 Поддержка

### Документация
- 📖 README.md - Полная документация
- ❓ FAQ.md - Частые вопросы
- 🎯 MARKETING.md - Маркетинг

### Контакты
- Telegram: @yoursupport
- Email: support@yourbot.com

---

## ✅ Чек-лист после установки

- [ ] Бот запущен и отвечает
- [ ] Токен бота настроен
- [ ] API ключ DeepInfra работает
- [ ] Крипто-адреса заменены на ваши
- [ ] Уведомления админу настроены
- [ ] Описание в BotFather заполнено
- [ ] Команды в BotFather настроены
- [ ] Изображение бота загружено
- [ ] Тестовая регистрация пройдена
- [ ] Тестовый запрос к AI выполнен
- [ ] Автозапуск настроен
- [ ] Бэкапы настроены

---

## 🎉 Поздравляем!

Ваш AI-бот готов к работе! 🚀

Следующие шаги:
1. Протестируйте все функции
2. Пригласите первых пользователей
3. Начните продвижение
4. Мониторьте работу

**Успехов! 💪**
